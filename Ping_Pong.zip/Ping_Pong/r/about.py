text_about="This is a Pygame-Based Project made by Dev Radadia.\n\n\nControls :-\nW and S : To move Left paddle Up and Down\nUp and Down (Arrows) : To move Right paddle Up and Down\n\n\nSet your name, choose your paddle colour, and PLAY ON !!! "

txt_return_btn="Return to Main Menu"
