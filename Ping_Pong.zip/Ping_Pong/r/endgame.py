win_statement=" Wins!" 

play_again_btn_txt="Play Again"
return_to_mainmenu_button_txt = "Return to Main Menu"
quit_button_txt = "Quit"
