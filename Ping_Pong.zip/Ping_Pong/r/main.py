r_title_label_txt = "Ping-Pong"

r_1Player_txt = "1 Player"
r_2Players_txt = "2 Players"
r_quit_button_txt = "Quit"
r_about_button_txt = "About"