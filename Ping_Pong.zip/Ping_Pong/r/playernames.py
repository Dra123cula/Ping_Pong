playernames_label_txt = "Player Names"

p_label_txt = "Player"
ai_label_txt = "Computer"

p1_label_txt = "Player 1"
p2_label_txt = "Player 2"

name_label_txt = "Name :"

color_blue_label_txt = "Blue"
color_green_label_txt = "Green"
color_yellow_label_txt = "Yellow"
color_pink_label_txt = "Pink"
color_red_label_txt = "Red"

return_to_mainmenu_button_txt = "Return to Main Menu"
enter_button_txt = "Enter"
