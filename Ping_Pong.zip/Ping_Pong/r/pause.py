paused_label_txt = "PAUSED"

resume_button_txt = "Resume"
return_to_mainmenu_button_txt = "Return to Main Menu"
quit_button_txt = "Quit"
