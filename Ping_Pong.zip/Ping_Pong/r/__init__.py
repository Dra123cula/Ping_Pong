from . import game
from . import main
from . import endgame
from . import colors
from . import font_size
from . import pause
from . import playernames
from . import about
from . import db_info

__all__=['main', 'game', 'endgame', 'colors', 'font_size', 'pause', 'playernames', 'about', 'db_info']
